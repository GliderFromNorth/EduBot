# Dialogflow Chatbot Generator
This project is to generate zip file to import dataset to Dialogflow.
You need to have 
agent(file)
package(file)
intent(folder)-contains json files which we create using chatbotgenerator.ipynb after reading book1.csv

zip (agent,package,intent) together and upload to dialogflow using import.it will be working fine.
if you find any problems with my code,do contribute
Have a look at friendlybot.zip and smalltalk.zip created by using chatbot generator
