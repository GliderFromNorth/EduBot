import React from "react";


const DeptList =()=> {
    return (
        <div>
            Department In SaKec.
        </div>
    )
}
export default DeptList;
