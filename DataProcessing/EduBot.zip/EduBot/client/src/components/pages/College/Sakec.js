import React from "react";
import DeptList from "./DeptList";
const SaKec =()=> {
    return (
        <div>
            <h2>SaKec</h2>
            <DeptList/>
        </div>
    )
};
export default SaKec;
//optimise code here. remove return and curly braces, You can even make it One liner.
/**
 * const SaKec =()=>
        <div>
            <h2>SaKec</h2>
            <DeptList/>
        </div>
    )
 export default SaKec;

 */


