import React from "react";


const Landing =()=> {
    return (
        <div style={{textAlign:'center'}}>
            <h1>Helping you with Queries!</h1>
            With EduBot.
        </div>
    )
}
export default Landing;
